﻿var total;
var unans;
var ans = 0;
var anslater = 0;
var ids = new Array();
var k = 0;

$(document).ready(function () {
    total = $("#<%= lblques.ClientID %>").html();
    unans = parseInt($("#<%= lblques.ClientID %>").html());
    var austDay = new Date();
    austDay.setHours(austDay.getHours() + 3);
    //austDay.setSeconds(austDay.getSeconds() + 10);
    $('#countdown').countdown({ until: austDay, format: 'HMS', onExpiry: submitExam });
});

function submitExam() {
    alert('Your time has been completed. Your paper is being submitted');
    $('#C1_btnSave').click();
}

function answerLater(qid) {
    $('#alater').show();
    $('#ansltr').append("<tr><td>");
    $('#ansltr').append($('#' + qid));
    $('#ansltr').append("</ td></ tr>");
    anslater++;
    $('#anslater').html(anslater);
}

function updateAnswers(qid) {
    if (in_array(qid) == 1) {
        ids[k] = qid;
        k++;
        total--;
        ans++;
        unans--;
        $('#ans').html(ans);
        $('#unans').html(unans);
        $('[name=answered]').val(ans);
        $('[name=unanswered]').val(unans);
        return;
    }
}

function in_array(val) {
    for (var i = 0; i < ids.length; i++) {
        if (ids[i] == val) {
            return 0;
            break;
        }
    }
    return 1;
}
