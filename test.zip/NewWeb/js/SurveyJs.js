﻿$(document).ready(function () {

    $('[id$=AddRowSurvey]').click(function () {

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/Ajax/jQueryAjax.aspx/AddRowSurvey",
            data: '{"option":"' + $('[id$=txtOptionSurvey]').val() + '"}',
            dataType: "json",
            success: function (data) {
                for (var i = 0; i < data.d.length; i++) {
             
                    $("#dataTable").append("<TR><TD align='center'  class='inner_tbl'><INPUT type='checkbox' name='chk'/></TD><TD align='center' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionName + "</TD><TD align='left'  class='inner_tbl'><INPUT type='radio' runat='server'  name='rdo' value='" + data.d[i].OptionName + "' /></TD></TR>");
                }
                $('[id$=txtOptionSurvey]').val('');
            },
            failure: function (response) {
                alert(response.d);

            },
            error: function (response) {
                alert(response.d);
            }

        });
    });
});



function deleteRowSurvey(tableID) {
    try {
        var table = document.getElementById(tableID);
        var rowCount = table.rows.length;
        for (var i = 0; i < rowCount; i++) {
            var row = table.rows[i];
            var chkbox = row.cells[0].childNodes[0];

            if (null != chkbox && true == chkbox.checked) {
                $.ajax({
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "/ajax/jqueryAjax.aspx/DelRowSurvey",
                    data: '{"Row":"' + i + '"}',
                    dataType: "json",
                    success: function (data) {
                    },
                    failure: function (response) {
                        alert(response.d);
                    },
                    error: function (response) {
                        alert(response.d);
                    }
                });
                table.deleteRow(i);
                rowCount--;
                i--;
            }
        }
    } catch (e) {
        alert(e);
    }
}

function selectRowSurvey(row_id) {
    try {
        var table = document.getElementById(row_id);
        var rowCount = table.rows.length;
        for (var i = 0; i < rowCount; i++) {
            var row = table.rows[i];
            var rdo = row.cells[2].childNodes[0];
            if (null != rdo && true == rdo.checked) {
                $.ajax({
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "/ajax/jqueryAjax.aspx/selectRowSurvey",
                    data: '{"Row":"' + i + '"}',
                    dataType: "json",
                    success: function (data) {
                    },
                    failure: function (response) {
                        alert(response.d);
                    },
                    error: function (response) {
                        //                        alert(response.d);
                        //                        alert('E')
                    }
                });
            }
        }
    } catch (e) {
        alert(e);
    }
}
