﻿// JScript File
String.prototype.ReplaceAll = function (stringToFind, stringToReplace) {
    var temp = this;
    var index = temp.indexOf(stringToFind);
    while (index != -1) {
        temp = temp.replace(stringToFind, stringToReplace);
        index = temp.indexOf(stringToFind);
    }
    return temp;
}
  function SetLogoutCookie(value)
        {
            var exdate=new Date();
            exdate.setDate(exdate.getDate()+1);
            var expires = "; expires="+exdate.toGMTString();
            document.cookie = "logout=" + value + expires+"; path=/";
        }

        function Checklogout()
        {
            var c_start = document.cookie.indexOf("logout=");
            if (c_start!=-1)
            {
                c_start=c_start + 7; 
                c_end=document.cookie.indexOf(";",c_start)
                if (c_end==-1) 
                {
                    c_end=document.cookie.length;
                }
                if(document.cookie.substring(c_start,c_end) == "true")
                {
                    return true;
                }                
            }
            return false;
        }

        function RedirectToLoginPage() {

            //document.body.innerHTML = document.body.innerHTML.ReplaceAll("Member", "Affiliate");
            if (Checklogout())
            {
                window.location = "/";
            }
        }

