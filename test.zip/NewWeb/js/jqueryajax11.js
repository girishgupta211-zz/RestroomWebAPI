﻿function Get_UserName(obj) {
    $.ajax({
        url: "ajax/jqueryAjax.aspx/Get_UserName",
        type: "POST",
        data: '{"Memberid":"' + $(obj).val() + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "!") {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='error'><span class='arrow'></span>Member not Exists</span>");
                $(obj).text('');
                return false;
            }
            else {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='data'>" + msg.d + "</span>");
                return true;
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);
        },
        failure: function (msg) {
            //            alert(msg);
        }
    });
}

function BinaryLevel() {
    var MemberId = $('[id$=txtMemberid]').val()
    var Levelno = $('input:radio[name=level]:checked').val();
    $.ajax({
        url: "ajax/jqueryAjax.aspx/BinaryLevel",
        type: "POST",
        data: '{"Memberid":"' + MemberId + '","Levelno":"' + Levelno + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "!") {
                $("#data").html("Error");
                return false;
            }
            else {
                $("#data").html(msg.d);
                return true;
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);

        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}

function DirectLevel() {
    var MemberId = $('[id$=txtMemberid]').val()
    var Levelno = $('input:radio[name=level]:checked').val();
    $.ajax({
        url: "ajax/jqueryAjax.aspx/DirectLevel",
        type: "POST",
        data: '{"Memberid":"' + MemberId + '","Levelno":"' + Levelno + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "!") {
                $("#data").html("Error");
                return false;
            }
            else {
                $("#data").html(msg.d);
                return true;
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);

        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}
function AvailableFund(obj) {
    var bal = $('[id$=txtcbal]');
    $.ajax({
        url: "ajax/jqueryAjax.aspx/AvailableFund",
        type: "POST",
        data: '{"Memberid":"' + $(obj).val() + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "!") {
                bal.val('0');
            }
            else {
                bal.val(msg.d);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);


        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}

function IsUserExists(obj) {
    if (!isID(obj)) {
        $(obj).parent().find("span").remove();
        $(obj).after("<span class='error'><span class='arrow'></span>field contain only a-z ,0-9 and 4-20 digit long</span>");
        return false;
    }
    $.ajax({
        url: "ajax/jqueryAjax.aspx/IsUserExists",
        type: "POST",
        data: '{"Memberid":"' + $(obj).val() + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "1") {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='error'><span class='arrow'></span>Member Already Exists</span>");
                $(obj).text('');
                return false;
            }
            else {
                $(obj).parent().find("span").remove();
                return true;
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);


        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}

function EpinAmtCalculate(obj) {
    var itemId = $('[id$=ddlScheme]').val();
    $.ajax({
        url: "ajax/jqueryAjax.aspx/EpinAmtCalculate",
        type: "POST",
        data: '{"totEpin":"' + $(obj).val() + '","ItemId":"' + itemId + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "0") {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='error'><span class='arrow'></span>invalid No of Epin</span>");
            }
            else {
                $('[id$=txtAmt]').val(msg.d);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);


        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}




$(document).ready(function () {
    $('[id$=ddlstate]').change(function () {
        $('[id$=ddlcity]').html('');
        $('[id$=ddlcity]').append($("<option></option>").val('0').html('--Select City--'));
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "ajax/jqueryAjax.aspx/BindCity",
            data: '{"stateid":"' + $('[id$=ddlstate]').val() + '"}',
            dataType: "json",
            success: function (data) {
                $.each(data.d, function (key, value) {
                    $('[id$=ddlcity]').append($("<option></option>").val(value.DistrictId).html(value.DistrictName));
                });
            },
            error: function (result) {
                //alert("Error");
            }
        });
    })

    $('[id$=AddRow]').click(function () {
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/Ajax/jQueryAjax.aspx/AddRow",
            data: '{"option":"' + $('[id$=ddlOption]').val() + '","optionvalue":"' + $('[id$=ddlOptionValue]').val() + '","OptionQty":"' + $('[id$=txtOptionQty]').val() + '","OptionName":"' + $('[id$=ddlOption] option:selected').text() + '","OptionValueName":"' + $('[id$=ddlOptionValue] option:selected').text() + '"}',
            dataType: "json",
            success: function (data) {

                for (var i = 0; i < data.d.length; i++) {
                    $("#dataTable").append("<TR><TD align='left'  class='inner_tbl'><INPUT type='checkbox' name='chk'/></TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].SrNo + "</TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionName + "</TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionValueName + "</TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionQty + "</TD></TD>");
                }
            },
            failure: function (response) {
                alert(response.d);

            },
            error: function (response) {
                alert(response.d);
            }
        });
    })


    $('[id$=ddlcategory]').change(function () {
        $('[id$=ddlsubcat1]').html('');
        $('[id$=ddlsubcat1]').append($("<option></option>").val('').html('--Select Subcategory1--'));

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "ajax/jqueryAjax.aspx/BindSubcategory",
            data: '{"Categoryid":"' + $('[id$=ddlcategory]').val() + '"}',
            dataType: "json",
            success: function (data) {
                $.each(data.d, function (key, value) {
                    $('[id$=ddlsubcat1]').append($("<option></option>").val(value.subcate_id).html(value.subcate_name));
                });
            },
            error: function (result) {
                //alert("Error");
            }
        });
    })

    $('[id$=ddlsubcat1]').change(function () {
        $('[id$=ddlsubcat2]').html('');
        $('[id$=ddlsubcat2]').append($("<option></option>").val('').html('--Select Subcategory2--'));

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "ajax/jqueryAjax.aspx/BindSubcategory2",
            data: '{"subcat1id":"' + $('[id$=ddlsubcat1]').val() + '"}',
            dataType: "json",
            success: function (data) {
                $.each(data.d, function (key, value) {
                    $('[id$=ddlsubcat2]').append($("<option></option>").val(value.subcate2_id).html(value.subcate2_name));
                });
            },
            error: function (result) {
                //alert("Error");
            }
        });
    })

    $(function () {
        $(".daymonthpicker").datepicker({
            changeMonth: true,
            changeYear: true,
            yearRange: '-80:+0',
            nextText: "&raquo;",
            prevText: "&laquo;",
            showAnim: "slideDown"
        });
    });
});


