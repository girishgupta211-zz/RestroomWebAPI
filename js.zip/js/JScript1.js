﻿$(document).ready(function () {
    $('[id$=AddRow]').click(function () {
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/Ajax/jQueryAjax.aspx/AddRow",
            data: '{"option":"' + $('[id$=txtoption]').val() + '"}',
            dataType: "json",
            success: function (data) {
                for (var i = 0; i < data.d.length; i++) {
                    $('[id$=dataTable]').append("<TR><TD align='left'  class='inner_tbl'><INPUT type='checkbox' name='chk'/></TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionName + "</TD><TD align='left'  class='inner_tbl'><INPUT type='radio' runat='server'  name='rdo' value='" + data.d[i].OptionName + "' /></TD></TR>");
                }
                $('[id$=txtoption]').val('');
            },
            failure: function (response) {
                // alert(response.d);
            },
            error: function (response) {
                // alert(response.d);
            }
        });
    })


    $('[id$=ddlcategory]').change(function () {
        $('[id$=ddlsubcat1]').html('');
        $('[id$=ddlsubcat1]').append($("<option></option>").val('0').html('--Select Subcategory1--'));

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "ajax/jqueryAjax.aspx/BindSubcategory",
            data: '{"Categoryid":"' + $('[id$=ddlcategory]').val() + '"}',
            dataType: "json",
            success: function (data) {
                $.each(data.d, function (key, value) {
                    $('[id$=ddlsubcat1]').append($("<option></option>").val(value.subcate_id).html(value.subcate_name));
                });
            },
            error: function (result) {
                //alert("Error");
            }
        });
    })

    $(document).ready(function () {
        $('[id$=ddlstate]').change(function () {
            $('[id$=ddlcity]').html('');
            $('[id$=ddlcity]').append($("<option></option>").val('0').html('--Select City--'));
            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "ajax/jqueryAjax.aspx/BindCity",
                data: '{"stateid":"' + $('[id$=ddlstate]').val() + '"}',
                dataType: "json",
                success: function (data) {
                    $.each(data.d, function (key, value) {
                        $('[id$=ddlcity]').append($("<option></option>").val(value.DistrictId).html(value.DistrictName));
                    });
                },
                error: function (result) {
                    //alert("Error");
                }
            });
        })


        $('[id$=ddlsubcat1]').change(function () {
            $('[id$=ddlsubcat2]').html('');
            $('[id$=ddlsubcat2]').append($("<option></option>").val('0').html('--Select Subcategory2--'));

            $.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "ajax/jqueryAjax.aspx/BindSubcategory2",
                data: '{"subcat1id":"' + $('[id$=ddlsubcat1]').val() + '"}',
                dataType: "json",
                success: function (data) {
                    $.each(data.d, function (key, value) {
                        $('[id$=ddlsubcat2]').append($("<option></option>").val(value.subcate2_id).html(value.subcate2_name));
                    });
                },
                error: function (result) {
                    //alert("Error");
                }
            });
        })

        $("input[name$='cars']").click(function () {
            var test = $(this).val();
            $(".desc").hide();
            $("#Cars" + test).show();
        });

        $("input[name$='upload']").click(function () {
            var test = $(this).val();
            $(".type").hide();
            $("#video" + test).show();
            ///toggleVisibility('[id$=video' + test + ']');
            //toggleVisibility(test)
        });

        $('#txtmobile').blur(function (e) {
            if (validatePhone('txtmobile')) {
                $('#spnPhoneStatus').html('');
                $('#spnPhoneStatus').css('color', 'green');
            }
            else {
                $('#spnPhoneStatus').html('Invalid');
                $('#spnPhoneStatus').css('color', 'red');
            }
        });

        $('#txtpayperclick').change(UpdateInfo);
        /// $('#grade').change(UpdateInfo);

//        $(function () {
//            $(".daymonthpicker").datepicker({
//                changeMonth: true,
//                changeYear: true,
//                yearRange: '-80:+0',
//                nextText: "&raquo;",
//                prevText: "&laquo;",
//                showAnim: "slideDown"
//            });
//        });
    });



    $("input[name$='cars']").click(function () {
        var test = $(this).val();

        $(".desc").hide();
        $("#Cars" + test).show();
    });

    $("input[name$='upload']").click(function () {
        var test = $(this).val();

        $(".type").hide();
        $("#video" + test).show();
    });

    $('#txtmobile').blur(function (e) {
        if (validatePhone('txtmobile')) {
            $('#spnPhoneStatus').html('');
            $('#spnPhoneStatus').css('color', 'green');
        }
        else {
            $('#spnPhoneStatus').html('Invalid');
            $('#spnPhoneStatus').css('color', 'red');
        }
    });

    //    $("#txtemail").blur(function () {
    //        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    //        var emailaddress = $("#Email").val();
    //        if (!emailReg.test(emailaddress))
    //            $("#Span1").html('<font color="#cc0000">Please enter valid Email address</font>');
    //        else
    //        $("#Span1").html('<font color="#cc0000"></font>');
    //    });

    $('#txtpayperclick').change(UpdateInfo);
    /// $('#grade').change(UpdateInfo);

});

function toggleVisibility(controlId) {
    var control = document.getElementById(video + controlId);
    if (control.style.visibility == "hidden")
        control.style.visibility = "visible";
    else
        control.style.visibility = "hidden";
}

function UpdateInfo() {
    var budget = $('[id$=txtbudget]').val()
    var payperclick = $('[id$=txtpayperclick]').val()
    var info = budget / payperclick;
    $('[id$=txttotalclick]').val(info);
}



function validatePhone(txtmobile) {
    var a = document.getElementById(txtmobile).value;
    var filter = /^[0-9-+]+$/;
    if (filter.test(a)) {
        return true;
    }
    else {
        return false;
    }
}


function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 45 || charCode > 57)) {
        return false;
    }
    return true;
}

function deleteRow(tableID) {
    try {

        var table = document.getElementById(tableID);
        var rowCount = table.rows.length;
        for (var i = 0; i < rowCount; i++) {
            var row = table.rows[i];
            var chkbox = row.cells[0].childNodes[0];
            if (null != chkbox && true == chkbox.checked) {
                $.ajax({
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "/ajax/jqueryAjax.aspx/DelRow",
                    data: '{"Row":"' + i + '"}',
                    dataType: "json",
                    success: function (data) {
                    },
                    failure: function (response) {
                        //   alert(response.d);
                    },
                    error: function (response) {
                        //   alert(response.d);
                    }
                });
                table.deleteRow(i);
                rowCount--;
                i--;
            }
        }
    } catch (e) {
        alert(e);
    }
}

function Get_UserName(obj) {
    $.ajax({
        url: "ajax/jqueryAjax.aspx/Get_UserName",
        type: "POST",
        data: '{"Memberid":"' + $(obj).val() + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "!") {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='error'><span class='arrow'></span>Member not Exists</span>");
                $(obj).text('');
                return false;
            }
            else {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='data'>" + msg.d + "</span>");
                return true;
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //alert(textStatus);
        },
        failure: function (msg) {
            // alert(msg);
        }
    });
}
