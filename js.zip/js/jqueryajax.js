﻿function Get_UserName(obj) {
    $.ajax({
        url: "ajax/jqueryAjax.aspx/Get_UserName",
        type: "POST",
        data: '{"UserName":"' + $(obj).val() + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        cache: false,
        success: function (msg) {
            if (msg.d.charAt(0) == "#") {
                $(obj).parent().find("span").remove();
                $(obj).after("<span class='error' style='color:red;'><span class='arrow'></span>User already exists..!</span>");
                $(obj).text('');
                return false;
            }
            else {
                $(obj).parent().find("span").remove();
                //  $('[id$=txtSponserName]').val(msg.d);
//                $(obj).parent().find("span").remove();
//                $(obj).after("<span class='data'>" + msg.d + "</span>");
                return true;
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            //            alert(textStatus);


        },
        failure: function (msg) {
            //            alert(msg);
        }

    });

}


$(document).ready(function () {
    $('[id$=ddlState]').change(function () {
        $('[id$=ddlCity]').html('');
        $('[id$=ddlCity]').append($("<option></option>").val('').html('--Select--'));
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "ajax/jqueryAjax.aspx/BindState",
            data: '{"STCode":"' + $('[id$=ddlState]').val() + '"}',
            dataType: "json",
            success: function (data) {
                $.each(data.d, function (key, value) {
                    $('[id$=ddlCity]').append($("<option></option>").val(value.DistrictId).html(value.DistrictName));
                });
            },
            error: function (result) {
                //alert("Error");
            }
        });
    })

    $('[id$=AddRow]').click(function () {
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/Ajax/jQueryAjax.aspx/AddRow",
            data: '{"option":"' + $('[id$=txtOption]').val() + '"}',
            dataType: "json",
            success: function (data) {

                for (var i = 0; i < data.d.length; i++) {
                    $("#dataTable").append("<TR><TD align='left'  class='inner_tbl'><INPUT type='checkbox' name='chk'/></TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].SrNo + "</TD><TD align='left' bgcolor='#FFFFFF' class='inner_tbl'>" + data.d[i].OptionName + "</TD>");
                }
                $('[id$=txtOption]').val('');
            },
            failure: function (response) {
                alert(response.d);

            },
            error: function (response) {
                alert(response.d);
            }
        });
    })
});