﻿$(document).ready(function () {
    setTimeout(function () {
        $.fn.colorbox({ href: "res/popup.gif", open: true });
    }, 1500);
});  